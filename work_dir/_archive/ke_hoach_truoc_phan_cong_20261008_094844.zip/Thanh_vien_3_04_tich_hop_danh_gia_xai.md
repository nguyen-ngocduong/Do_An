# Thành viên 3 — 04: Tích hợp demo và đánh giá tính nhất quán XAI

- **Lịch đề xuất:** 02–15/11/2026; 5–6 buổi.
- **Phụ thuộc:** module TV3-03, model đóng băng TV2-03; ca test cuối lấy sau TV2-04.
- **Người kiểm tra:** thành viên 2.

## Công việc

- [ ] Hoàn thiện app dùng pipeline thật: CSV → xác thực → dự đoán → chọn mẫu/lớp → giải thích → xuất kết quả.
- [ ] Gắn model/run ID, schema và phương pháp XAI với kết quả; nhãn thật chỉ hiển thị khi CSV có nhãn hợp lệ, không đưa vào estimator.
- [ ] Cache theo model/dataset/sample/class/XAI config để không trả nhầm giải thích sau đổi model.
- [ ] Kiểm tra mẫu chuẩn: app/script khớp dự đoán và lớp, top feature/đóng góp khớp cấu hình.
- [ ] Sau đánh giá test đóng băng, chọn khoảng 12–20 ca test theo quy tắc đã viết: dự đoán đúng/sai trong 8 lớp, có Normal, lớp hiếm và các cặp lớp nhầm lẫn. Nếu một loại lỗi không tồn tại, ghi rõ; không dựng ca sai giả.
- [ ] Làm lại hình toàn cục/cục bộ cuối; ghi cách lấy mẫu và support, không dùng giải thích test để chọn lại model.
- [ ] Kiểm tra tính cộng SHAP trong đúng output space và dung sai; ghi tỷ lệ/độ lệch kiểm tra, lớp và explainer.
- [ ] Lặp cùng model/sample/config để kiểm tra tái lập; nếu dùng background, thử 3 seed chọn nền từ train cùng cỡ, so overlap top-5/top-10 và dấu đóng góp. Đây là ổn định trong thiết lập đã chọn, không chứng minh giải thích luôn đúng.
- [ ] Nếu làm LIME, lặp 5 seed trên cùng ca, ghi overlap/fidelity và giới hạn. Không bắt buộc SHAP và LIME giống nhau.
- [ ] Đo thời gian giải thích tách phần khởi tạo explainer và mỗi mẫu; cùng máy/cỡ mẫu, warm-up, nhiều lần, báo median/p95 nếu đủ lần.
- [ ] Kiểm tra lỗi CSV, hạn mức tài nguyên và demo offline; viết 3.5, 4.3 và phần XAI của 4.4.

## Đầu ra và nghiệm thu

Demo tích hợp, bộ ca test/XAI cuối, bảng tính nhất quán và thời gian, hình/bài phân tích đúng-sai, hướng dẫn vận hành.

Đạt khi người khác chạy được demo, mọi giải thích truy vết model/sample/class, có số đo ổn định/thời gian thực và giới hạn. Chưa có đủ bằng chứng để khẳng định triển khai edge hay thời gian thực.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Model/XAI run ID / ngày bàn giao / đường dẫn / người kiểm tra: điền sau.
- Bước tiếp theo: [TV3-05](Thanh_vien_3_05_demo_bao_cao_ban_giao.md).
