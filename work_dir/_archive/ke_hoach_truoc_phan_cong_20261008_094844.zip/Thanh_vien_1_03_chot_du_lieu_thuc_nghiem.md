# Thành viên 1 — 03: Chốt dữ liệu và phân tích đặc trưng

- **Lịch đề xuất:** 19/10–01/11/2026; 3–4 buổi.
- **Phụ thuộc:** TV1-02; số đo tài nguyên từ TV2-02.
- **Người kiểm tra:** thành viên 3.

## Công việc

- [ ] Chốt cỡ train chính theo pilot và nguồn lực thực; lưu cách lấy mẫu, seed, phân bố trước/sau và dataset ID.
- [x] Với các tập pilot giới hạn mẫu lớp đông, giữ toàn bộ BruteForce/Web-Based và công bố phân bố trước/sau; chưa chốt tập train chính.
- [x] Lưu validation/test cố định theo run và kiểm tra support đủ 8 lớp sau xử lý split/trùng; các model tiếp theo phải dùng chung bộ này để đối sánh.
- [x] Hoàn thiện kiểm tra giao nhau và nhãn mâu thuẫn; mô tả điều gì kiểm chứng được/không được với bản Kaggle.
- [x] Phân tích cột hằng và tương quan trên train; đưa ra danh sách feature đề xuất, không tự xóa feature theo test.
- [ ] Cùng TV2 thiết kế đối chiếu toàn bộ feature với bộ rút gọn nếu đủ thời gian; selection fit trên train, quyết định trên validation.
- [x] Lưu tên/thứ tự feature gốc và 44 feature đầu ra, danh sách log/scale và tham số biến đổi trong schema/config cho TV3.
- [ ] Hoàn thiện mô tả ý nghĩa và đơn vị của từng feature để diễn giải XAI đúng.
- [x] Lưu manifest/schema/mapping theo run ID riêng; đã có một phiên bản artifact cố định để bàn giao.
- [ ] Xác nhận TV2/TV3 cùng sử dụng run đã chọn; mọi thay đổi tiếp theo cần run ID mới và thông báo cho người nhận.
- [ ] Hoàn thiện hình phân bố/EDA cho 2.1–2.2 và phần dữ liệu của 4.1; chú thích nguồn và cỡ mẫu.

## Đầu ra và nghiệm thu

Dataset chính được nhận diện bằng manifest, báo cáo leakage/split, bảng support và feature schema đã chốt. TV2/TV3 xác nhận cùng dataset ID.

Đạt khi dữ liệu dùng cho bảng đối sánh tái tạo được, không lẫn pilot với dữ liệu chính, không có preprocessing fit lên validation/test. Nếu thiếu tài nguyên, dùng cỡ vừa đủ và báo cáo giới hạn thay vì khẳng định chạy toàn bộ CICIoT2023.

## Cập nhật tiến độ

- Cập nhật: **08/10/2026**.
- Trạng thái: **đã có phiên bản dữ liệu và audit; chưa chốt quy mô huấn luyện sau pilot**.
- Bằng chứng: [schema](../output/processed_data/20261007_164739_35f682b9/feature_schema.json), [support](../output/processed_data/20261007_164739_35f682b9/class_support_final.csv), [audit đầu vào mô hình](../output/processed_data/20261007_164739_35f682b9/effective_input_overlap_policy.json), [cột hằng](../output/processed_data/20261007_164739_35f682b9/constant_feature_audit.csv), [tương quan](../output/processed_data/20261007_164739_35f682b9/correlated_feature_pairs.csv).
- Dataset/run hiện có: `20261007_164739_35f682b9`; 46 feature đầu vào, 44 feature đầu ra. Bỏ Telnet/IRC theo train; không bỏ thêm feature theo tương quan.
- Validation giảm 26,74%, test giảm 29,44% so với nguồn sau hai lượt lọc; phải mô tả thay đổi phân bố này khi báo cáo. Audit JSON ghi giao nhau trước khi áp dụng mask của lượt tương ứng; không coi đó là phép kiểm tra độc lập sau xuất file.
- Đã tạo ba tập pilot 100k/500k/1M, seed 42, đủ 8 lớp; [phân bố trước/sau](../output/pilot_data/pilot_20261008_022915_ea9a88b0/class_distribution_all_budgets.csv), [manifest](../output/pilot_data/pilot_20261008_022915_ea9a88b0/pilot_manifest.json). Hai lớp hiếm được giữ toàn bộ, các lớp khác tăng theo budget.
- Preprocessing được fit trên toàn train nguồn và dùng cố định cho cả ba budget; thí nghiệm tiếp theo so sánh quy mô train classifier. Validation/test dùng lại run processing đã lọc trùng.
- Còn: kết quả benchmark để chốt quy mô, đơn vị feature, bản viết báo cáo, xác nhận bàn giao; đối chiếu bộ feature rút gọn là tùy chọn.
- Bước ngay tiếp theo: phối hợp [TV2-02 — baseline và đo tài nguyên](Thanh_vien_2_02_huan_luyen_baseline.md), so sánh macro-F1/recall lớp hiếm, thời gian và RAM trên cùng validation để chốt budget. Sau đó tiếp tục [TV1-04](Thanh_vien_1_04_kiem_chung_tai_lap.md).

