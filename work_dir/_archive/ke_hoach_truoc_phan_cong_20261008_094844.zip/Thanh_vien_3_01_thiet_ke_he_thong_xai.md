# Thành viên 3 — 01: Thiết kế hệ thống và kế hoạch XAI

- **Vai trò:** XAI, giao diện, tích hợp; ưu tiên thực hiện đầu tiên.
- **Lịch đề xuất:** 07–11/10/2026; 2–3 buổi.
- **Phụ thuộc:** bắt đầu ngay; chốt schema cùng TV1/TV2.
- **Người kiểm tra:** thành viên 1.

## Công việc

- [ ] Đọc yêu cầu hệ thống và XAI trong đề cương; đọc tài liệu [3]/[4], ghi chép các ý liên quan đã kiểm chứng.
- [ ] Vẽ kiến trúc: CSV → kiểm tra schema → pipeline → dự đoán → XAI theo yêu cầu → biểu đồ/xuất kết quả.
- [ ] Chốt SHAP là phần chính: toàn cục trên tập mẫu có cấu hình và cục bộ trên từng mẫu. LIME bổ sung sau khi phần bắt buộc ổn.
- [ ] Chốt giao diện minh họa Streamlit: tải CSV feature, xem nhãn dự đoán thuộc 8 lớp và xác suất theo 8 lớp, chọn sample ID/lớp giải thích và top feature; xem confusion matrix 8 × 8 từ thực nghiệm.
- [ ] Thống nhất contract cùng TV1/TV2: thứ tự feature, class order, sample ID, run ID, kiểu dự đoán/xác suất, artifact và vị trí đầu ra.
- [ ] Thiết kế kết quả XAI chứa class index/name, baseline, đóng góp, không gian đầu ra và thời gian. Không hiển thị đóng góp SHAP như xác suất nếu chưa xác minh.
- [ ] Lập tiêu chí đánh giá: kiểm tra tính cộng SHAP đúng output, lặp lại cùng cấu hình, thay mẫu nền có kiểm soát, overlap top-k và thời gian.
- [ ] Thiết kế giao diện mẫu bằng dữ liệu giả được ghi rõ; chưa coi đó là demo model thật.
- [ ] Viết nháp yêu cầu 3.1, dàn ý 2.4 và sơ đồ hệ thống.

## Đầu ra và nghiệm thu

`docs/system_design.md`, `docs/xai_protocol.md`, sơ đồ kiến trúc, schema kết quả XAI và bản phác giao diện.

Đạt khi dòng dữ liệu, trách nhiệm từng module và điều kiện demo rõ ràng. Phạm vi là hệ thống thử nghiệm offline trên feature CSV; chỉ làm thêm thời gian thực khi các mục bắt buộc đã xong.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Ngày hoàn thành thực tế / đường dẫn đầu ra / người kiểm tra: điền khi bàn giao.
- Bước tiếp theo: [TV3-02](Thanh_vien_3_02_shap_giao_dien_mau.md).
