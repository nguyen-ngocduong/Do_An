# Thành viên 1 — 04: Kiểm chứng dữ liệu và chạy lại quy trình

- **Lịch đề xuất:** 02–15/11/2026; 3–4 buổi.
- **Phụ thuộc:** dữ liệu đóng băng TV1-03; runner/model TV2-03; app/XAI TV3-03.
- **Người kiểm tra:** thành viên 3.

## Công việc

- [ ] Tái tạo dữ liệu từ cấu hình/manifest trên môi trường hoặc thư mục sạch, không dựa vào biến notebook đang giữ trong RAM.
- [ ] Đối chiếu số dòng/lớp, checksum/schema, feature order, mapping và split với lần chạy chính.
- [x] Kiểm tra fitted preprocessing thuộc train; không có target/target-derived column trong feature.
- [ ] Kiểm tra dữ liệu test đã đóng băng và độc lập theo quy tắc protocol; ghi giới hạn nếu không có metadata phiên.
- [ ] Dùng mẫu chuẩn đối chiếu script/notebook/app cùng đầu vào, cùng pipeline và cùng class order.
- [ ] Kiểm tra CSV thiếu cột, sai dtype, Inf/NaN, cột nhãn đi kèm: app xử lý theo schema và không học lại trên CSV tải lên.
- [ ] Phối hợp TV2 tính bảng support và tỷ lệ nhầm Normal/lớp hiếm từ dự đoán test sau khi model đã đóng băng.
- [ ] Hoàn thiện hướng dẫn nguồn dữ liệu, tiền xử lý, lấy mẫu và cách tái tạo; mọi bước thay đổi có log.
- [ ] Ghi kết quả kiểm chứng cho phần dữ liệu của 4.1 và giới hạn 4.4.

## Đầu ra và nghiệm thu

`docs/reproduction_check.md`, báo cáo kiểm tra dữ liệu cuối, log chạy lại và hướng dẫn chuẩn bị dữ liệu.

Đạt khi người khác chuẩn bị được cùng dữ liệu/model input mà không sửa thủ công, các sai khác được giải thích. Không yêu cầu kết quả float khớp tuyệt đối giữa mọi phần cứng; xác định dung sai và môi trường.

## Cập nhật tiến độ

- Cập nhật: **08/10/2026**.
- Trạng thái: **đã rà nguồn fit và schema; chưa thực hiện kiểm chứng tái lập toàn quy trình**.
- Đã đọc mã notebook và [cấu hình preprocessing](../output/processed_data/20261007_164739_35f682b9/preprocessing_config.json): median/scaler/feature selection từ train; ma trận feature không chứa nhãn và metadata.
- Đã đọc báo cáo, đối chiếu header/kích thước NPY; đây không phải chạy lại pipeline trên môi trường sạch hay kiểm thử app.
- Chưa có lần tái lập độc lập, model hoặc giao diện để kiểm chứng các mục còn lại.
- Bước tiếp theo: [TV1-05](Thanh_vien_1_05_bao_cao_ban_giao.md).

