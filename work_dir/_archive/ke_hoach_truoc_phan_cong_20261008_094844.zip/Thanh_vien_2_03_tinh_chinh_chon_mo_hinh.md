# Thành viên 2 — 03: Tinh chỉnh và chọn mô hình bằng validation

- **Lịch đề xuất:** 19/10–01/11/2026; 4–5 buổi và thời gian máy chạy.
- **Phụ thuộc:** 3 baseline TV2-02; dữ liệu chính TV1-03.
- **Người kiểm tra:** thành viên 1.

## Công việc

- [ ] Huấn luyện cả 3 thuật toán cho bài toán phân loại 8 lớp trên cùng train chính đã chốt; ghi rõ kết quả nào thuộc pilot.
- [ ] Tìm kiếm ít cấu hình có chủ đích: LR regularization/max_iter; DT depth/min_samples_leaf; RF n_estimators/depth/min_samples_leaf/max_features.
- [ ] Dùng validation để chọn cấu hình theo macro-F1 và kiểm tra lớp hiếm/Normal; không điều chỉnh theo test.
- [ ] Ghi ngân sách tìm kiếm từng thuật toán và cảnh báo hội tụ, thời gian/RAM; chỉ dùng CV nếu ngân sách và nhóm split cho phép.
- [ ] So sánh cơ chế cân bằng hợp lệ trên train. Nếu sampling đã đổi phân bố, ghi rõ weighting thêm có thể gây điều chỉnh quá mức.
- [ ] Làm đối chiếu feature đầy đủ/rút gọn nếu đủ thời gian; kiểm tra cả chất lượng và thời gian, không mặc định rút gọn sẽ tốt hơn.
- [ ] Chạy 3 seed mô hình trên cùng split nếu đủ tài nguyên; báo trung bình/độ lệch và từng run. Không chọn seed theo điểm test.
- [ ] Chốt model dùng demo/XAI dựa trên validation, tài nguyên và khả năng giải thích. Nếu model có macro-F1 cao nhất khác model demo, báo hai lựa chọn và lý do.
- [ ] Đóng băng pipeline/model/schema và metadata; bàn giao TV3, xác nhận SHAP tương thích trước M4.
- [ ] Viết phần lựa chọn model và bảng validation cho báo cáo.

## Đầu ra và nghiệm thu

Bảng validation chính thức cho 3 model, log tìm kiếm, danh sách cấu hình được chọn, artifact đóng băng và ghi chép quyết định model/demo.

Đạt khi mọi quyết định chốt trước đánh giá test, cùng dữ liệu/protocol, model bàn giao nạp được và class order rõ ràng. Không có ngưỡng accuracy bắt buộc chưa được đề cương quy định.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Model/run ID / ngày chốt / đường dẫn / người kiểm tra: điền sau.
- Bước tiếp theo: [TV2-04](Thanh_vien_2_04_danh_gia_test_hieu_nang.md).
