# Thành viên 3 — 03: Giải thích toàn cục và cục bộ bằng SHAP

- **Lịch đề xuất:** 19/10–01/11/2026; 4–5 buổi.
- **Phụ thuộc:** SHAP thử TV3-02; feature schema TV1-03; model từ TV2-03. Dùng baseline trong khi chờ, gắn đúng run ID.
- **Người kiểm tra:** thành viên 2.

## Công việc

- [ ] Chọn explainer tương thích model cây và phiên bản thực chạy; lưu loại explainer, output space, cấu hình và seed.
- [ ] Nếu explainer cần background, lấy từ train, lưu sample ID/cỡ mẫu; không lấy test làm nền để tinh chỉnh.
- [ ] Chọn tập giải thích validation cố định, có Normal/lớp hiếm/lớp đông; ghi phương pháp lấy mẫu và support.
- [ ] Làm biểu đồ toàn cục mean absolute SHAP cho từng lớp trong 8 lớp và tổng hợp; nếu mẫu cân bằng lớp, nói rõ biểu đồ không đại diện tần suất lưu lượng tự nhiên.
- [ ] Lập khoảng 12–20 ca validation điển hình của bài toán 8 lớp: đúng Normal, đúng từng nhóm tấn công nếu có mẫu, nhầm Normal với một nhóm cụ thể và nhầm giữa hai nhóm tấn công; ưu tiên lỗi thực sự tồn tại và ghi rõ nhãn thật/dự đoán 8 lớp.
- [ ] Mỗi ca lưu sample ID, true/predicted label, xác suất nếu có, lớp giải thích, top feature, baseline và đóng góp.
- [ ] Đối chiếu feature với đặc điểm lưu lượng ở mức giả thuyết; không diễn giải XAI là bằng chứng quan hệ nhân quả.
- [ ] Xử lý tương quan feature trong phần giới hạn và diễn giải; không tự khẳng định một feature là nguyên nhân tấn công.
- [ ] Nếu đủ thời gian, chạy LIME trên cùng ca/lớp; lưu seed và local fidelity nếu công cụ cung cấp, không đòi thứ hạng trùng SHAP.
- [ ] Tích hợp trang giải thích toàn cục/cục bộ và xuất kết quả; viết nháp 2.4/3.4.

## Đầu ra và nghiệm thu

Module XAI cấu hình được, hình toàn cục theo lớp, tập ca validation với giải thích bằng văn bản, cấu hình/background và app đọc được kết quả.

Đạt khi mọi hình truy vết model/sample/class, mô tả rõ không gian đầu ra và phương pháp lấy mẫu. Chưa sử dụng ca validation này như bằng chứng test cuối.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- XAI config/run ID / ngày bàn giao / đường dẫn / người kiểm tra: điền sau.
- Bước tiếp theo: [TV3-04](Thanh_vien_3_04_tich_hop_danh_gia_xai.md).
