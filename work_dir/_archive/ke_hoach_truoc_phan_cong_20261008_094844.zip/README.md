# Kế hoạch đồ án tốt nghiệp — nhóm 07, 3 thành viên

**Đề tài:** Nghiên cứu, xây dựng hệ thống phát hiện tấn công mạng IoT dựa trên kỹ thuật XAI.

**Phạm vi đã chốt theo yêu cầu của nhóm:** chỉ thực hiện bài toán phân loại có giám sát **8 lớp**. Toàn bộ dữ liệu, 3 mô hình đối sánh, chỉ số đánh giá, XAI, giao diện và báo cáo sử dụng cùng 8 lớp này. Nhãn gốc chỉ phục vụ truy vết và ánh xạ sang 8 lớp.

Kế hoạch được lập ngày **07/10/2026** từ `../Đề cương đồ án tốt nghiệp.docx` và rà soát `../notebook/ciciot2023-do-an.ipynb`. Đề cương ghi ngày giao 25/09/2026, ngày nộp quyển **06/12/2026**. Lịch dưới đây là lịch đề xuất từ thời điểm lập kế hoạch; không coi công việc trong quá khứ là đã hoàn thành.

## Tiến độ cập nhật ngày 08/10/2026

- [x] Đã thực hiện EDA train và bàn giao ảnh khảo sát.
- [x] Đã chạy pipeline preprocessing trên Kaggle, ánh xạ đúng 8 lớp và lưu bộ artifact `20261007_164739_35f682b9`.
- [x] Đã có schema/manifest/mapping, kiểm tra NaN/Inf, trùng xuyên tập, nhãn mâu thuẫn, cột hằng/tương quan, hai transformer và support sau xử lý.
- [x] Đã chốt phạm vi 8 lớp, mã lớp và chỉ số đánh giá chính macro-F1.
- [x] Tạo pilot 100k/500k/1M có index/seed, đủ 8 lớp và giữ toàn bộ BruteForce/Web-Based.
- [ ] Đo ngân sách huấn luyện và kết quả validation để chốt cỡ train chính.
- [ ] Huấn luyện, đánh giá và lưu ít nhất 3 mô hình baseline.
- [ ] Tích hợp SHAP và giao diện minh họa.
- [ ] Hoàn thiện báo cáo các phần dữ liệu/phương pháp và kiểm chứng tái lập độc lập.

**Vị trí hiện tại:** đã hoàn thành preprocessing và tạo pilot; bước tiếp theo là [TV2-02 — huấn luyện baseline, đo RAM/thời gian](Thanh_vien_2_02_huan_luyen_baseline.md) để TV1-03 chốt cỡ train. TV1-01 còn phần viết nháp; TV1-02 còn báo cáo và CSV mẫu cho giao diện. Các task huấn luyện, XAI, giao diện và thực nghiệm cuối chưa có bằng chứng hoàn thành.

Pilot: [run_status](../output/pilot_data/pilot_20261008_022915_ea9a88b0/run_status.json), [manifest](../output/pilot_data/pilot_20261008_022915_ea9a88b0/pilot_manifest.json), [bàn giao](../output/pilot_data/pilot_20261008_022915_ea9a88b0/README_HANDOFF.md). Run hoàn tất trên Kaggle trong 238,782 giây; kiểm tra checksum 30 file tải về và header/kích thước 6 ma trận feature đạt. Các kiểm tra index lồng nhau, nhãn/metadata và giá trị feature khớp nguồn được ghi đạt trong manifest Kaggle. `benchmark_template.csv` vẫn có 9 thí nghiệm `not_run`; chưa có điểm mô hình để chọn budget.

Bằng chứng: [trạng thái run](../output/processed_data/20261007_164739_35f682b9/run_status.json), [cấu hình](../output/processed_data/20261007_164739_35f682b9/preprocessing_config.json), [support cuối](../output/processed_data/20261007_164739_35f682b9/class_support_final.csv). Train **5.357.406 × 44**, validation **862.150 × 44**, test **830.443 × 44**, đủ 8 lớp ở mỗi tập. Các dấu tick mới dựa trên mã và artifact đã đọc; giữ các dấu tick người dùng đã đánh trước đó. Xác nhận nghiệm thu riêng giữa các thành viên vẫn cần thực hiện. Không chạy lại notebook hoặc huấn luyện trên local khi cập nhật tiến độ.

## Cách sử dụng và quy tắc đặt tên

Đề cương chưa điền tên 3 sinh viên. Khi chưa có tên, dùng `Thanh_vien_1`, `Thanh_vien_2`, `Thanh_vien_3`; thay bằng tên thật không dấu khi nhóm chốt phân công, đồng thời cập nhật liên kết trong tài liệu này.

Mỗi người có 5 file công việc: **`Ten_nguoi_01_...md` → `Ten_nguoi_05_...md`**. Số nhỏ làm trước. Các file cùng số là các công việc có thể khởi động song song, nhưng phải tuân thủ điều kiện bàn giao ghi trong từng file. Số thể hiện thứ tự thực hiện, không phải mức độ quan trọng của thành viên. Chỉ đánh dấu checklist hoàn thành khi có đầu ra và người kiểm tra xác nhận.

| Người phụ trách tạm thời | Trách nhiệm chính | Phần báo cáo chủ trì |
| --- | --- | --- |
| Thành viên 1 | Nguồn dữ liệu, EDA, chia tập, tiền xử lý, tái lập dữ liệu | Chương I; 2.1–2.2; 3.2; phần dữ liệu của 4.1 |
| Thành viên 2 | Thiết kế thực nghiệm, 3 mô hình, suy luận, đánh giá | 2.3; 3.3; cấu hình mô hình của 4.1; 4.2; thời gian suy luận trong 4.4 |
| Thành viên 3 | Kiến trúc hệ thống, SHAP/LIME, giao diện, tích hợp | 2.4; 3.1; 3.4–3.5; 4.3; thời gian giải thích trong 4.4 |

Cả nhóm cùng viết Mở đầu, kết luận, giới hạn và định hướng phát triển; mỗi người chịu trách nhiệm nội dung của mình và kiểm tra một phần của người khác. Phân công có thể đổi theo thế mạnh thực tế nhưng mỗi đầu ra phải có một người chịu trách nhiệm chính.

## Đọc các file theo thứ tự này

| Ưu tiên | Thành viên 1 — dữ liệu | Thành viên 2 — mô hình | Thành viên 3 — XAI/giao diện |
| --- | --- | --- | --- |
| 01 | [Khảo sát, xác minh dữ liệu](Thanh_vien_1_01_khao_sat_du_lieu.md) | [Thiết kế thực nghiệm](Thanh_vien_2_01_thiet_ke_thuc_nghiem.md) | [Thiết kế hệ thống và XAI](Thanh_vien_3_01_thiet_ke_he_thong_xai.md) |
| 02 | [Pipeline tiền xử lý](Thanh_vien_1_02_pipeline_tien_xu_ly.md) | [Huấn luyện 3 mô hình](Thanh_vien_2_02_huan_luyen_baseline.md) | [SHAP và giao diện mẫu](Thanh_vien_3_02_shap_giao_dien_mau.md) |
| 03 | [Chốt dữ liệu thực nghiệm](Thanh_vien_1_03_chot_du_lieu_thuc_nghiem.md) | [Tinh chỉnh, chọn mô hình](Thanh_vien_2_03_tinh_chinh_chon_mo_hinh.md) | [XAI toàn cục/cục bộ](Thanh_vien_3_03_xai_toan_cuc_cuc_bo.md) |
| 04 | [Kiểm chứng dữ liệu, tái lập](Thanh_vien_1_04_kiem_chung_tai_lap.md) | [Đánh giá test và thời gian](Thanh_vien_2_04_danh_gia_test_hieu_nang.md) | [Tích hợp, đánh giá XAI](Thanh_vien_3_04_tich_hop_danh_gia_xai.md) |
| 05 | [Báo cáo phần dữ liệu](Thanh_vien_1_05_bao_cao_ban_giao.md) | [Báo cáo thực nghiệm](Thanh_vien_2_05_bao_cao_ban_giao.md) | [Demo và báo cáo XAI](Thanh_vien_3_05_demo_bao_cao_ban_giao.md) |

## Kết quả rà soát EDA ban đầu ngày 07/10/2026

Notebook có 40 cell, tập trung vào EDA. Theo **output đã lưu trong notebook, chưa chạy lại để xác minh**, bản dữ liệu đang dùng có train 5.491.971 dòng, validation và test mỗi tập 1.176.851 dòng; dữ liệu ban đầu có 46 đặc trưng và 1 cột `label`. Bản này lấy từ Kaggle và đã chia tập; không được tự coi là toàn bộ dữ liệu gốc CICIoT2023.

Notebook đã thống kê nhãn, ánh xạ 34 nhãn gốc thành 8 nhóm và vẽ biểu đồ. Chưa thấy phần huấn luyện, lưu mô hình, SHAP/LIME, ứng dụng hay đánh giá cuối. Một số điểm cần xử lý trước:

**Cập nhật:** đã có 7 ảnh EDA và bộ output preprocessing `20261007_164739_35f682b9`. Các thiếu sót kỹ thuật nêu dưới đây là hiện trạng EDA ban đầu, đã được xử lý trong notebook preprocessing chạy trên Kaggle; xem checklist và phần còn thiếu trong [task 1](Thanh_vien_1_01_khao_sat_du_lieu.md). Bộ hình processing mới có phân bố 8 lớp sau khử trùng; ảnh EDA `02b` ban đầu vẫn mô tả 34 nhãn gốc.

- Tiêu đề notebook đang mô tả bài toán “Unsupervised Anomaly Detection”; cần chỉnh cho khớp bài toán **phân loại có giám sát 8 lớp**. Biểu đồ Normal/Anomaly hiện có không phải đầu ra yêu cầu; các bảng và biểu đồ chính phải thể hiện 8 lớp.
- Output đã lưu báo 134.565 dòng trùng trong train; cần kiểm tra lại và kiểm tra giao nhau train/validation/test. Đây chưa phải kết luận rằng các tập bị rò rỉ.
- Báo cáo cuối notebook loại cột `category` nhưng thực tế dùng `attack_category`, dẫn đến đếm 47 đặc trưng sau ánh xạ. Khi học máy phải loại **mọi cột nhãn/nhãn dẫn xuất**, dùng danh sách đặc trưng cho phép.
- Cell tương quan ghi “sample 100k” nhưng đặt `sample_size = len(df_train)`; phần phân bố cũng lấy toàn bộ train. Đổi thành cỡ mẫu cấu hình được để tránh tốn RAM.
- Đường dẫn đang gắn với Kaggle; cần cấu hình đường dẫn cho local/Kaggle và thống nhất thư mục xuất biểu đồ.
- Ánh xạ 8 lớp mới thể hiện trên train; cần áp dụng cùng quy tắc cho validation/test và báo lỗi nếu có nhãn không xác định.

**Trong 48 giờ đầu:** thành viên 1 lập kiểm kê dữ liệu và kiểm tra notebook; thành viên 2 chốt protocol thí nghiệm; thành viên 3 chốt giao diện dữ liệu/mô hình/XAI. Cả nhóm chốt nguồn dữ liệu, định nghĩa nhãn và nơi chạy thí nghiệm trước khi huấn luyện chính thức.

## Phạm vi và sản phẩm phải có

1. Quy trình dữ liệu CICIoT2023 chạy lại được; nguồn, phiên bản, cấu trúc cột, ánh xạ nhãn, cách lấy mẫu và chia tập được ghi rõ.
2. Đối sánh tối thiểu **3 mô hình**. Đề xuất ban đầu: Logistic Regression, Decision Tree, Random Forest để có mô hình tuyến tính và mô hình cây. Đây là lựa chọn triển khai của kế hoạch, không phải danh sách bắt buộc trong đề cương.
3. Bài toán duy nhất **8 lớp** theo thứ tự thống nhất: Normal, BruteForce, DDoS, DoS, Mirai, Recon, Spoofing, Web-Based. Cả 3 mô hình được huấn luyện và đối sánh cho đúng bài toán này. Nhãn gốc được giữ làm metadata phục vụ kiểm tra mapping; cột đích huấn luyện là nhãn 8 lớp.
4. **SHAP là phương pháp XAI chính** cho mô hình cây phù hợp. LIME là phần bổ sung khi phần bắt buộc đã chạy ổn; đề cương cho phép “SHAP và/hoặc LIME”. XAI phục vụ phân tích quyết định, không tự được xem là cách tăng độ chính xác.
5. Giao diện minh họa đề xuất dùng Streamlit: nhập CSV đặc trưng, kiểm tra định dạng, dự đoán, chọn mẫu để giải thích, xem biểu đồ và xuất kết quả. Không yêu cầu bắt gói thời gian thực hay triển khai IDS sản xuất.
6. Bảng precision/recall/F1/support cho đủ 8 lớp, macro-F1, confusion matrix **8 × 8** với cùng thứ tự lớp; thời gian huấn luyện, suy luận và giải thích; phân tích dự đoán đúng/sai, lớp hiếm và tính nhất quán XAI.
7. Mã nguồn, môi trường/phụ thuộc, cấu hình, mô hình, biểu đồ/bảng, hướng dẫn chạy, báo cáo nhóm và bảng đóng góp cá nhân.

## Lịch thực hiện đến hạn nộp

| Mốc | Ngày | Công việc chính và điều kiện hoàn thành |
| --- | --- | --- |
| M1 — chốt thiết kế | 07–11/10 | Hoàn thành ưu tiên 01; thống nhất nguồn dữ liệu, nhãn, protocol, cấu trúc đầu ra và ngân sách tính toán |
| M2 — pipeline chạy xuyên suốt | 12–18/10 | Có dữ liệu thử nghiệm hợp lệ; 3 mô hình baseline có kết quả validation; SHAP một mẫu và giao diện mẫu đọc được đầu ra |
| M3 — đối sánh đầu tiên | 19–25/10 | Có bảng đối sánh 3 mô hình trên cùng dữ liệu; kiểm tra RAM/thời gian; quyết định cỡ dữ liệu chính thức |
| M4 — chốt mô hình | 26/10–01/11 | Hoàn thành ưu tiên 03; lựa chọn bằng validation, chốt pipeline/model trước khi đánh giá test; có XAI toàn cục/cục bộ trên validation |
| M5 — tích hợp | 02–08/11 | Giao diện dùng artifact thật, người khác chạy được; không còn lỗi schema/nhãn/thứ tự đặc trưng |
| M6 — thực nghiệm cuối | 09–15/11 | Hoàn thành ưu tiên 04; có kết quả test, benchmark, phân tích XAI cuối và log tái lập |
| M7 — báo cáo bản đầy đủ | 16–22/11 | Hoàn thành bản thảo Mở đầu và Chương I–IV, kết luận, bảng phân công; toàn bộ hình/bảng có nguồn sinh và mô tả |
| M8 — phản biện, sửa, đóng gói | 23–29/11 | Chạy lại quy trình trên môi trường thứ hai; sửa theo góp ý giảng viên; chốt mã, kết quả, demo và bản báo cáo |
| M9 — dự phòng và nộp | 30/11–05/12 | Rà định dạng, tài liệu tham khảo, số liệu, in/đóng quyển theo quy định khoa; sao lưu và diễn tập trình bày |
| Hạn chính thức | **06/12/2026** | Nộp quyển đúng hạn ghi trong đề cương; ngày bảo vệ chưa có trong tài liệu, cần xác nhận riêng |

Các file ưu tiên 05 bắt đầu gom nội dung từ đầu; tuần 16–29/11 là thời gian hoàn thiện. Không đợi thực nghiệm kết thúc mới viết các phần tổng quan/phương pháp.

## Quy tắc thực nghiệm chung

- Chốt tập chia và manifest trước huấn luyện. Nếu bản Kaggle có split sẵn, xác minh nguồn, nhãn và giao nhau trước khi dùng. Khi có nguồn file/phiên/thời gian đáng tin, ưu tiên split theo nhóm; không coi tên CSV đơn thuần là một phiên độc lập. Nếu chỉ có dữ liệu dòng đã trộn, chia theo nhóm hash đặc trưng để giữ mẫu trùng trong cùng tập và ghi rõ giới hạn không kiểm chứng được tính độc lập theo phiên.
- Kiểm tra nhãn mâu thuẫn trên cùng vector đặc trưng và xử lý theo quy tắc được ghi trong báo cáo. Không âm thầm xóa lớp hiếm hoặc loại cả một nhóm tấn công để làm đẹp kết quả.
- Chỉ fit imputer, scaler, bộ chọn đặc trưng và cơ chế cân bằng trên train; validation/test chỉ transform. Các tham số quyết định/tinh chỉnh chọn trên validation. Quy tắc này theo [hướng dẫn tránh rò rỉ dữ liệu của scikit-learn](https://scikit-learn.org/stable/common_pitfalls.html).
- Dùng cùng train/validation/test, cùng bộ đặc trưng và ngân sách tìm kiếm công bố cho 3 mô hình. Nếu preprocessing khác theo mô hình, ghi rõ và lưu cùng model trong pipeline.
- Dữ liệu lớn: chạy pilot khoảng 100.000 dòng train với cách lấy mẫu giữ các lớp hiếm, sau đó chọn cỡ train chính thức theo RAM/thời gian. Có thể giới hạn mẫu lớp đông, giữ lớp hiếm; phải công bố phân bố trước/sau. Validation/test giữ phân bố kiểm thử tự nhiên; nếu cần giảm cỡ, lưu cùng một mẫu cố định cho mọi mô hình và công bố giới hạn.
- Chỉ số chọn chính: macro-F1 trên validation với bộ nhãn cố định gồm đủ 8 lớp; kiểm tra thêm recall/F1/support của từng lớp, đặc biệt Normal và lớp hiếm. Accuracy/weighted-F1 là chỉ số bổ sung. Nếu một tập thiếu lớp, báo rõ support bằng 0 và quy tắc xử lý chỉ số không xác định. Không đặt mục tiêu accuracy tùy ý như 99% làm tiêu chí hoàn thành.
- Tách chạy thử khỏi chạy cuối. Đóng băng model, preprocessing và protocol trước đánh giá test. Không dùng điểm test để chọn lại model. Nếu phát hiện lỗi, ghi bản bị hủy và lý do; kết quả sửa phải được nhận diện rõ là test đã được xem.
- Benchmark cùng máy, cùng batch, có warm-up, nhiều lần chạy; tách thời gian nạp model, tiền xử lý, dự đoán và giải thích. Ghi CPU/RAM, phiên bản môi trường, số mẫu và thống kê trung vị/p95 nếu đủ số lần.
- XAI phải gắn với đúng mẫu, lớp đầu ra, model và không gian đầu ra. SHAP đa lớp cần kiểm tra hình dạng và ánh xạ lớp; giá trị SHAP không mặc nhiên là xác suất. Tham khảo [TreeExplainer](https://shap.readthedocs.io/en/stable/generated/shap.TreeExplainer.html).
- Seed, cấu hình, checksum/manifest dữ liệu, phiên bản package và mã commit được lưu với từng lần chạy. Đánh giá độ ổn định mô hình bằng 3 seed ở cỡ dữ liệu đã chốt nếu đủ tài nguyên; nếu thiếu, công bố số lần thực chạy.

## Giao diện bàn giao giữa 3 người

Đây là cấu trúc **đề xuất sẽ triển khai**, chưa phải các file đã tồn tại:

| Đầu ra | Người tạo → người nhận | Nội dung tối thiểu |
| --- | --- | --- |
| `data_manifest.json`, `label_mapping.json`, `feature_schema.json` | TV1 → TV2, TV3 | Nguồn/phiên bản, checksum hoặc ID tập, split, số dòng/lớp, cột và kiểu dữ liệu, thứ tự feature, quy tắc nhãn |
| `train/validation/test` hoặc manifest index | TV1 → TV2 | Cùng dữ liệu đóng băng, không chứa nhãn trong ma trận đặc trưng, truy vết được sample ID |
| `pipeline.joblib`, `model_metadata.json` | TV2 → TV3 | Preprocessing đã fit và model, mapping mã lớp sang đúng 8 tên/thứ tự lớp, schema, run ID, cấu hình, điểm validation, ID dữ liệu |
| `metrics.csv`, `predictions.parquet` | TV2 → TV1, TV3 | Metrics theo model/split/8 lớp; sample ID, nhãn thật 8 lớp nếu có, nhãn dự đoán 8 lớp, xác suất của đủ 8 lớp theo thứ tự đã chốt nếu được hỗ trợ |
| `explanations/`, `xai_metrics.csv`, `app/` | TV3 → TV1, TV2 | Sample ID/run ID, lớp được giải thích, phương pháp, đặc trưng, đóng góp, baseline/đầu ra SHAP, thời gian, hình và ứng dụng |

TV1 kiểm tra dữ liệu bàn giao; TV2 chịu trách nhiệm model và chỉ số; TV3 chịu trách nhiệm diễn giải và hiển thị. Người nhận xác nhận bàn giao trước khi làm phần phụ thuộc. Dùng 10–20 mẫu cố định để kiểm tra rằng suy luận trong notebook, script và giao diện cho cùng kết quả.

## Cấu trúc mã nguồn đề xuất

```text
DATN/
├── notebook/                 # Khám phá và minh họa
├── work_dir/                 # Kế hoạch hiện tại
├── configs/                  # Dữ liệu, mô hình, thực nghiệm, XAI
├── src/
│   ├── data/                 # Import, kiểm tra, chia tập, preprocessing
│   ├── models/               # Train, predict, lưu/nạp artifact
│   ├── evaluation/           # Metrics và benchmark
│   └── xai/                  # SHAP; LIME khi đủ thời gian
├── app/                      # Giao diện minh họa
├── data/                     # Dữ liệu lớn không đưa lên Git
├── artifacts/                # Model và metadata theo run
├── results/                  # Metrics, dự đoán, hình, giải thích
└── docs/                     # Báo cáo phần việc và hướng dẫn vận hành
```

Môi trường đề xuất: Python với pandas/numpy, scikit-learn, SHAP, matplotlib/seaborn, joblib, Streamlit; pyarrow nếu dùng Parquet; LIME tùy chọn. Chọn phiên bản thực tế sau pilot và khóa phụ thuộc đã chạy ổn; không tự coi `.venv` hiện có là môi trường đã kiểm chứng. Chỉ tạo các module cần cho quy trình này.

## Kiểm soát tiến độ và nghiệm thu

Họp nhóm 2 lần/tuần, 20–30 phút: cập nhật checklist, kiểm tra đầu ra và chốt việc tuần tiếp theo. Mỗi công việc cập nhật ngày bắt đầu/kết thúc thực tế, đường dẫn đầu ra, run ID và trở ngại. Nhóm tự chốt người liên hệ giảng viên và lịch xin góp ý; kế hoạch không tự gửi tin nhắn.

| Rủi ro | Cách xử lý và thời điểm quyết định |
| --- | --- |
| Dữ liệu quá lớn/RAM không đủ | Đo pilot trước 18/10; đọc theo chunk, lưu dạng gọn, lấy mẫu có cấu hình; giảm train cùng cách cho 3 model |
| Split Kaggle không truy vết hoặc có mẫu trùng xuyên tập | TV1 xử lý trước M2; xây lại split theo quy tắc công bố khi cần, không giữ số liệu cũ sau thay split |
| Lớp hiếm thiếu mẫu | Giữ support, đánh giá từng lớp, ưu tiên 8 nhóm; công bố trường hợp không đủ mẫu, không gộp/xóa tùy tiện |
| SHAP chậm hoặc không tương thích | TV3 chạy thử với model cây ngay M2; chọn cấu hình XAI hữu hạn, cache theo model+sample+config; bảo đảm vẫn có SHAP toàn cục/cục bộ |
| Không đủ thời gian | Cắt LIME, mô hình bổ sung, thời gian thực và triển khai edge trước; giữ đối sánh 3 model phân loại 8 lớp, SHAP, demo, đánh giá và báo cáo |
| Kết quả thấp | Phân tích lỗi và lớp hiếm, kiểm tra dữ liệu/protocol; báo cáo kết quả thực, không đổi split hay xem test để tìm số đẹp |
| Báo cáo trễ | Viết Chương I–III song song từ tháng 10; chốt bản đầy đủ 22/11, dành 30/11–05/12 làm dự phòng |

Đồ án hoàn thành khi người khác chạy lại được quy trình đã ghi; có 3 model phân loại 8 lớp so sánh trên cùng protocol; SHAP toàn cục/cục bộ theo lớp và trường hợp đúng/sai; demo dự đoán 8 lớp hoạt động; bảng metrics/thời gian và giới hạn; báo cáo đúng cấu trúc đề cương, nguồn tham khảo và đóng góp 3 người; bộ bàn giao được kiểm tra trước hạn.

## Nguồn dùng khi lập kế hoạch

- Nguồn yêu cầu và hạn nộp: `../Đề cương đồ án tốt nghiệp.docx`.
- Nguồn hiện trạng: `../notebook/ciciot2023-do-an.ipynb`; chỉ đọc mã/output lưu sẵn, chưa thực thi lại.
- [CICIoT2023 — trang chính thức UNB/CIC](https://www.unb.ca/cic/datasets/iotdataset-2023.html): dữ liệu gồm 33 loại tấn công thuộc 7 nhóm; cộng lưu lượng lành tính thành 8 nhóm như notebook hiện tại. Phải kiểm tra bản dữ liệu thực dùng và mapping cụ thể.
- [scikit-learn — Common pitfalls](https://scikit-learn.org/stable/common_pitfalls.html): nguyên tắc chia tập và fit preprocessing để tránh leakage.
- [SHAP — TreeExplainer](https://shap.readthedocs.io/en/stable/generated/shap.TreeExplainer.html): lựa chọn explainer, không gian đầu ra, đa lớp và kiểm tra tính cộng.

4 tài liệu tham khảo trong đề cương phải được các thành viên đọc, ghi chép và trích dẫn sau khi xác minh. Kế hoạch này không thay việc tổng quan nghiên cứu liên quan.
