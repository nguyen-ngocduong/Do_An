# Thành viên 1 — 02: Xây pipeline dữ liệu và tiền xử lý

- **Lịch đề xuất:** 12–18/10/2026; 4–5 buổi.
- **Phụ thuộc:** TV1-01 và protocol/schema chung đã chốt.
- **Người kiểm tra:** thành viên 2.

## Công việc

- [x] Tổ chức các hàm nhập, kiểm tra dữ liệu và mapping dùng lại trong notebook; cấu hình đường dẫn chạy trên Kaggle theo yêu cầu hiện tại của nhóm.
- [x] Xác thực cột/dtype và nhãn; loại `label`, `attack_category`, mọi nhãn dẫn xuất và ID/metadata khỏi feature bằng danh sách cho phép. Cột đích là mã 8 lớp (`class_id`, xuất thành `y_*`); nhãn gốc giữ trong metadata riêng.
- [x] Áp dụng cùng mapping 8 lớp trên train/validation/test; thống nhất mã lớp và thứ tự Normal, BruteForce, DDoS, DoS, Mirai, Recon, Spoofing, Web-Based. Nhãn gốc chỉ giữ làm metadata; nhãn lạ phải báo lỗi trước khi huấn luyện.
- [x] Xử lý NaN/Inf và trùng theo quyết định kiểm kê; ghi số dòng trước/sau và nguyên nhân.
- [x] Kiểm tra split sẵn bằng fingerprint; áp dụng `purge_eval` theo thứ tự train → validation → test, lưu số mẫu bị loại, manifest và giới hạn chưa kiểm chứng độc lập theo phiên.
- [x] Tạo pilot khoảng 100.000 dòng train, giữ lớp hiếm, seed cố định; không thay phân bố kiểm thử chỉ để cân bằng.
- [x] Đóng gói hai transformer dùng lại: `tree_preprocessor.joblib` chọn cột/điền thiếu và `scaled_preprocessor.joblib` thêm log/scale; metadata và schema được lưu cùng run.
- [x] Fit mọi phép biến đổi học từ dữ liệu trên train; thống kê chọn feature cũng chỉ dùng train. Validation/test dùng transform.
- [x] Đổi cỡ mẫu vẽ/tương quan sang cấu hình; lưu bảng/hình kèm cỡ mẫu và seed.
- [x] Viết hướng dẫn tái tạo và sử dụng dữ liệu pilot trong notebook Kaggle và README bàn giao.
- [ ] Viết mục 2.2/3.2 của báo cáo.

## Đầu ra và nghiệm thu

Đầu ra thực tế theo yêu cầu chạy Kaggle: [notebook processing](../notebook/ciciot2023-do-an-processing.ipynb), [cấu hình run](../output/processed_data/20261007_164739_35f682b9/preprocessing_config.json), manifest/schema/mapping, hai transformer, ma trận X/y, sample metadata và hình/bảng audit. Đã tạo pilot 100k/500k/1M: [manifest](../output/pilot_data/pilot_20261008_022915_ea9a88b0/pilot_manifest.json), [hướng dẫn bàn giao](../output/pilot_data/pilot_20261008_022915_ea9a88b0/README_HANDOFF.md) và [notebook tái tạo](../notebook/ciciot2023-do-an-pilot.ipynb).

Đạt khi TV2 đọc được dữ liệu không sửa tay, split không giao nhau theo quy tắc đã chọn, class/feature order ổn định, đầu vào không chứa nhãn. TV3 có một CSV feature hợp lệ và mẫu thiếu/sai cột để kiểm tra giao diện.

## Cập nhật tiến độ

- Cập nhật: **08/10/2026**.
- Trạng thái: **pipeline đã chạy và xuất artifact trên Kaggle; đã tạo pilot; còn báo cáo và mẫu CSV cho giao diện**.
- Run `20261007_164739_35f682b9` hoàn tất ngày 07/10/2026; [run_status.json](../output/processed_data/20261007_164739_35f682b9/run_status.json).
- Train **5.357.406 × 44**, validation **862.150 × 44**, test **830.443 × 44**; cả ba tập đủ 8 lớp theo [support cuối](../output/processed_data/20261007_164739_35f682b9/class_support_final.csv).
- Đã đối chiếu header/kích thước các NPY với manifest; chưa chạy lại pipeline hoặc huấn luyện trên local.
- Pilot `pilot_20261008_022915_ea9a88b0` hoàn tất trên Kaggle trong 238,782 giây: 100.000/500.000/1.000.000 dòng × 44 feature, seed 42, đủ 8 lớp; mỗi tập giữ 1.488 BruteForce và 2.768 Web-Based. Manifest ghi các index lồng nhau, không lặp ID và X/y/metadata khớp nguồn.
- Đã kiểm tra checksum 30 file tải về, header/kích thước 6 ma trận feature và hash config/nhãn nguồn. Chỉ đọc artifact, không chạy lại notebook, xử lý dữ liệu hoặc huấn luyện trên local.
- Còn: viết mục 2.2/3.2, chuẩn bị CSV mẫu hợp lệ/lỗi cho TV3. Chưa có xác nhận TV2/TV3 đã nạp và sử dụng bộ dữ liệu.
- Bước tiếp theo: [TV1-03](Thanh_vien_1_03_chot_du_lieu_thuc_nghiem.md).

