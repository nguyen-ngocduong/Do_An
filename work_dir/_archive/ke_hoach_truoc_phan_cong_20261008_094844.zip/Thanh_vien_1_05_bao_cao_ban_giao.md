# Thành viên 1 — 05: Hoàn thiện báo cáo dữ liệu và bàn giao

- **Lịch đề xuất:** viết nháp từ tháng 10; hoàn thiện 16–29/11; rà/nộp 30/11–06/12/2026.
- **Phụ thuộc:** phần số liệu cuối nhận sau TV1-04 và TV2-04.
- **Người kiểm tra:** thành viên 3.

## Công việc

- [ ] Hoàn thiện Chương I: IoT, nhóm tấn công, IDS/ML và vai trò XAI; tránh lặp lý do chọn đề tài.
- [ ] Hoàn thiện 2.1–2.2, 3.2 và phần dữ liệu 4.1: nguồn thực dùng, nhãn, mapping, split, sampling, preprocessing, leakage và giới hạn.
- [ ] Kiểm tra mọi số dòng/feature/support khớp manifest; phân biệt dữ liệu gốc, bản Kaggle, pilot và train chính.
- [ ] Chèn hình EDA chất lượng đủ in, có số hình, chú thích, cỡ mẫu, nguồn và đường dẫn tái sinh.
- [ ] Rà tài liệu tham khảo liên quan dữ liệu/IoT, đối chiếu nguồn đã đọc và trích dẫn; không chép nội dung chưa kiểm chứng.
- [ ] Cùng nhóm hoàn thiện Mở đầu, mục tiêu/phạm vi, phương pháp và bảng đóng góp 3 người.
- [ ] Chuẩn bị hướng dẫn tải/định vị dữ liệu, tái tạo split và chạy pipeline; không đưa dữ liệu lớn lên Git.
- [ ] Kiểm tra phần kiến trúc/XAI của TV3, đối chiếu schema/feature với dữ liệu.
- [ ] Chạy lại phần chuẩn bị dữ liệu từ hướng dẫn cuối và ghi môi trường thực chạy.
- [ ] Trước 05/12 xác nhận bộ bàn giao/sao lưu và bản quyển đúng yêu cầu khoa; nộp ngày 06/12 theo đề cương.

## Đầu ra và nghiệm thu

Bản thảo phần được phân công, hình/bảng nguồn, hướng dẫn dữ liệu và bảng đóng góp cá nhân.

Đạt khi nội dung khớp thực nghiệm, nguồn trích dẫn rõ, người khác tái tạo dữ liệu được. Bản đầy đủ gửi nhóm rà ngày 22/11; chốt sửa mục tiêu 29/11.

## Chuẩn bị trình bày

Giải thích được vì sao chọn CICIoT2023/bản dữ liệu đang dùng; cách tránh rò rỉ, xử lý lớp hiếm, lý do chia 8 lớp và giới hạn split.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Ngày hoàn thành thực tế / bản báo cáo / đường dẫn / người kiểm tra: điền sau.

