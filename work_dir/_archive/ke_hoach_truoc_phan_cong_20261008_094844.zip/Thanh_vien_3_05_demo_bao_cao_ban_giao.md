# Thành viên 3 — 05: Hoàn thiện demo, báo cáo XAI và bộ bàn giao

- **Lịch đề xuất:** viết nháp từ tháng 10; hoàn thiện 16–29/11; rà/nộp 30/11–06/12/2026.
- **Phụ thuộc:** số liệu/demo cuối TV3-04 và model/results TV2-04.
- **Người kiểm tra:** thành viên 2.

## Công việc

- [ ] Hoàn thiện 2.4, 3.1, 3.4–3.5, 4.3 và phần thời gian XAI/giới hạn 4.4.
- [ ] Giải thích kiến trúc, luồng phân loại 8 lớp, SHAP toàn cục/cục bộ theo từng lớp, output space, background và ánh xạ đúng 8 lớp đầu ra.
- [ ] Chọn hình/ca đúng-sai đại diện, ghi sample/run ID và lời diễn giải thận trọng; không suy ra quan hệ nhân quả từ SHAP.
- [ ] Trình bày phép đo tính nhất quán, top-k, thời gian, số lần chạy và giới hạn; LIME chỉ mô tả nếu đã thực chạy.
- [ ] Đóng gói app, pipeline/config/metadata cần thiết, CSV demo feature, kết quả mẫu và hướng dẫn cài/chạy.
- [ ] Chạy demo trên môi trường thứ hai từ hướng dẫn; kiểm tra nhập CSV hợp lệ/lỗi, dự đoán, giải thích, xuất kết quả.
- [ ] Chuẩn bị kịch bản demo 5–7 phút: bài toán → nhập dữ liệu → dự đoán → ca đúng/sai → XAI → giới hạn.
- [ ] Chuẩn bị ảnh/video dự phòng của demo thật, ghi phiên bản; không dùng kết quả giả thay phần thực nghiệm.
- [ ] Cùng nhóm làm tài liệu trình bày và rà bố cục báo cáo, đánh số hình/bảng, mục lục, tài liệu tham khảo theo yêu cầu khoa.
- [ ] Rà phần mô hình/thực nghiệm của TV2; chốt app/artifact trước 29/11, sao lưu trước 05/12 và nộp quyển 06/12.
- [ ] Xác nhận ngày bảo vệ riêng với nhóm/giảng viên vì đề cương chỉ ghi ngày nộp quyển.

## Đầu ra và nghiệm thu

Bản thảo XAI/hệ thống, app hoàn chỉnh, bộ demo/hướng dẫn, hình/ca cuối, tài liệu trình bày và bảng đóng góp.

Đạt khi người khác vận hành được demo và mọi giải thích gắn đúng model/sample/class. Bản báo cáo đầy đủ gửi nhóm rà ngày 22/11.

## Chuẩn bị trình bày

Giải thích được SHAP đang giải thích gì, khác xác suất thế nào, ảnh hưởng của nền/tương quan feature, vì sao XAI không chứng minh nhân quả hay tự làm model chính xác hơn.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Ngày hoàn thành thực tế / bản báo cáo / đường dẫn / người kiểm tra: điền sau.
