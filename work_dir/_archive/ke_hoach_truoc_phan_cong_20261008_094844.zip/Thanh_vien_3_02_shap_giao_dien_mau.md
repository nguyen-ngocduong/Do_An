# Thành viên 3 — 02: Chạy SHAP thử và dựng giao diện mẫu

- **Lịch đề xuất:** 12–25/10/2026; 4–5 buổi.
- **Phụ thuộc:** thiết kế TV3-01; CSV/schema TV1-02; model cây thử từ TV2-02 để giải thích thật.
- **Người kiểm tra:** thành viên 2.

## Công việc

- [ ] Dựng app nhập CSV và hiển thị dự đoán bằng interface đã chốt; đánh dấu rõ dữ liệu giả trong thời gian chưa có model.
- [ ] Nạp pipeline/model từ metadata, xác thực feature schema trước suy luận; báo thiếu cột, sai kiểu, giá trị không hợp lệ.
- [ ] Chạy SHAP trên một số mẫu validation bằng Decision Tree hoặc Random Forest baseline.
- [ ] Truy cập đúng preprocessing và estimator; dữ liệu đi vào explainer phải giống dữ liệu estimator thực nhận.
- [ ] Kiểm tra hình dạng SHAP cho mô hình 8 lớp và ánh xạ `classes_`; biểu đồ giải thích đúng lớp trong 8 lớp đang chọn và đúng sample ID.
- [ ] Kiểm tra baseline + tổng đóng góp khớp đầu ra được giải thích trong không gian output đã chọn, theo mức sai số số học đã ghi.
- [ ] Hiển thị giá trị feature gốc hoặc sau biến đổi có ghi rõ đơn vị; thử waterfall/local bar cho một mẫu.
- [ ] Giới hạn cỡ CSV/demo và cỡ mẫu XAI theo đo pilot; tránh giải thích toàn bộ CSV mặc định.
- [ ] Kiểm tra cùng các mẫu chuẩn cho kết quả script/app; phân biệt nhãn thật nếu có với nhãn dự đoán.
- [ ] Ghi môi trường SHAP đã chạy ổn và các điểm cần xử lý trước phân tích chính thức.

## Đầu ra và nghiệm thu

App mẫu, module `src/xai/`, kết quả SHAP thật của vài mẫu validation, ghi chú tương thích và thời gian sơ bộ.

Đạt khi luồng CSV → pipeline → prediction → SHAP chạy được trên artifact thật, khớp lớp/feature/sample. Mock UI không đủ để nghiệm thu phần này.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Model/run ID / ngày bàn giao / đường dẫn / người kiểm tra: điền sau.
- Bước tiếp theo: [TV3-03](Thanh_vien_3_03_xai_toan_cuc_cuc_bo.md).
