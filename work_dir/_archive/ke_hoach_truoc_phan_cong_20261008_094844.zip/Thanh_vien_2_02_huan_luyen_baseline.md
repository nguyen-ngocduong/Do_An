# Thành viên 2 — 02: Huấn luyện và đối sánh 3 mô hình baseline

- **Lịch đề xuất:** 12–25/10/2026; 5–6 buổi và thời gian máy chạy.
- **Phụ thuộc:** protocol TV2-01; dữ liệu pilot/schema TV1-02. Có thể viết mã trước, chỉ chạy đối sánh khi dữ liệu đạt nghiệm thu.
- **Người kiểm tra:** thành viên 1.

## Công việc

- [ ] Viết cùng một runner train/evaluate cho Logistic Regression, Decision Tree, Random Forest; tham số lấy từ cấu hình.
- [ ] Huấn luyện cả 3 mô hình phân loại 8 lớp trên cùng pilot, cùng label mapping/feature list; scaler riêng cho mô hình tuyến tính nhưng lưu toàn bộ pipeline.
- [ ] Thử baseline không cân bằng và cấu hình class weight phù hợp trên train; ghi rõ tương tác nếu train đã lấy mẫu lại.
- [ ] Đánh giá validation: macro-F1, precision/recall/F1/support cho đủ 8 lớp và confusion matrix 8 × 8; thêm các chỉ số bổ sung.
- [ ] Kiểm tra đủ 8 lớp trong train, nhãn dự đoán thuộc mapping và xác suất có 8 cột đúng thứ tự lớp; bàn giao mapping mã lớp/tên lớp cho TV3.
- [ ] Đo RAM, thời gian fit và suy luận sơ bộ để đề xuất cỡ train chính thức; kiểm tra cảnh báo hội tụ của Logistic Regression.
- [ ] Lưu pipeline, class order, feature schema, cấu hình, phiên bản, run ID và dự đoán validation có sample ID.
- [ ] Bàn giao sớm một model cây đã học cho TV3 thử SHAP, không đợi hoàn tất cả bảng đối sánh.
- [ ] Kiểm tra 10–20 mẫu cố định cho suy luận trước/sau khi lưu/nạp model.
- [ ] Viết nháp 3.3 và bảng kết quả validation đầu tiên; chưa dùng test để chọn model.

## Đầu ra và nghiệm thu

3 model baseline có artifact nạp lại được, bảng validation theo model/lớp, confusion matrix, log fit và dự đoán validation. Cỡ dữ liệu/seed phải ghi trên mọi bảng.

Đạt khi cả 3 model chạy cùng protocol, metrics tính từ dự đoán đã lưu, metadata đủ để TV3 suy luận. Kết quả chưa phải kết quả test cuối.

## Cập nhật tiến độ

- Cập nhật: **08/10/2026**. Trạng thái: **đã có dữ liệu pilot; chưa huấn luyện**.
- Đầu vào: [pilot `pilot_20261008_022915_ea9a88b0`](../output/pilot_data/pilot_20261008_022915_ea9a88b0/pilot_manifest.json), 100k/500k/1M, seed 42, 44 feature, đủ 8 lớp; nguồn processing `20261007_164739_35f682b9`.
- Chạy trên Kaggle: bắt đầu ba model ở 100k, ghi macro-F1/recall từng lớp, RAM/thời gian và cảnh báo hội tụ; tiếp tục 500k/1M với cùng cấu hình khi tài nguyên cho phép. LR dùng scaled; Decision Tree/Random Forest dùng raw; không transform lại các ma trận đã xử lý.
- Dùng cùng validation 862.150 dòng; chưa dùng test để chọn budget/model. Preprocessing dùng cố định từ toàn train nguồn.
- [Bảng benchmark](../output/pilot_data/pilot_20261008_022915_ea9a88b0/benchmark_template.csv) hiện là mẫu trống với 9 dòng `not_run`; lưu kết quả thực trong output huấn luyện riêng. TV1 phối hợp chốt budget sau khi có số đo.
- Run mô hình / ngày bàn giao / người kiểm tra: điền sau.
- Bước tiếp theo: [TV2-03](Thanh_vien_2_03_tinh_chinh_chon_mo_hinh.md).
