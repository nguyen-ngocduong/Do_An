# Thành viên 1 — 01: Khảo sát và xác minh dữ liệu

- **Vai trò:** dữ liệu; ưu tiên thực hiện đầu tiên.
- **Lịch đề xuất:** 07–11/10/2026; 2–3 buổi làm việc.
- **Phụ thuộc:** không có; phối hợp TV2-01 và TV3-01 để chốt protocol/schema.
- **Người kiểm tra:** thành viên 2.

## Công việc

- [x] Đọc đề cương; đọc trang chính thức CICIoT2023 và tài liệu [1] của đề cương. Ghi nguồn, cách tạo đặc trưng, nhãn và giới hạn dữ liệu.
- [x] Kiểm kê bản Kaggle notebook đang dùng: phiên bản, đường dẫn, dung lượng, số dòng, cột, nhãn và cách chia sẵn. Không coi bản này là toàn bộ CICIoT2023.
- [x] Xác minh lại EDA trên train, tập trung phân bố và đặc trưng của 8 lớp; kiểm tra schema, NaN/Inf, lớp thiếu và support của đủ 8 lớp ở train/validation/test để xác nhận tính hợp lệ, không phân tích test để chọn mô hình.
- [x] Kiểm tra trùng vector đặc trưng trong từng tập, giao nhau giữa các tập và nhãn mâu thuẫn. Lập cách xử lý trước huấn luyện.
- [x] Kiểm tra mapping 34 nhãn gốc thành 8 lớp; nhãn gốc chỉ phục vụ kiểm tra ánh xạ/truy vết. Thống nhất tên/thứ tự Normal, BruteForce, DDoS, DoS, Mirai, Recon, Spoofing, Web-Based với TV2/TV3; nhãn lạ phải gây lỗi có thông báo.
- [x] Ghi các lỗi cần sửa: mục tiêu unsupervised chưa khớp hướng đề cương; đếm nhầm `attack_category` là feature; lấy mẫu bằng toàn bộ train; đường dẫn/plots gắn Kaggle.
- [x] Đo RAM/time đọc dữ liệu trên máy hoặc Kaggle dự kiến chạy; đề xuất cỡ pilot và cỡ train chính.
- [ ] Viết nháp mục 2.1 và dàn ý Chương I; ghi chú tài liệu bằng nguồn thực đã đọc.

## Đầu ra và nghiệm thu

Đã có [source manifest](../output/processed_data/20261007_164739_35f682b9/source_manifest.json), [mapping 8 lớp](../output/processed_data/20261007_164739_35f682b9/label_mapping.json), [feature schema](../output/processed_data/20261007_164739_35f682b9/feature_schema.json) và các báo cáo audit trong [bộ đầu ra tiền xử lý](../output/processed_data/20261007_164739_35f682b9/preprocessing_config.json). Nội dung báo cáo khảo sát bằng văn bản và nháp chương vẫn cần hoàn thiện; không bắt buộc đổi tên các artifact hiện có sang tên dự kiến ban đầu.

Đạt khi có nguồn/phiên bản xác định, bảng số dòng/lớp, danh sách 46 đặc trưng ban đầu được kiểm chứng theo dữ liệu thực dùng, kết quả kiểm tra trùng và quyết định split. Nếu thiếu metadata phiên, ghi rõ giới hạn; không suy đoán tên CSV là phiên độc lập.

## Cập nhật tiến độ

- Cập nhật: **08/10/2026**.
- Trạng thái: **đã hoàn thành khảo sát và kiểm tra dữ liệu; còn nháp mục 2.1/dàn ý Chương I**.
- Đã có notebook EDA, ảnh trong `plots/` và lần chạy Kaggle `20261007_164739_35f682b9` có [trạng thái complete](../output/processed_data/20261007_164739_35f682b9/run_status.json).
- Bằng chứng mới: kiểm tra schema/NaN/Inf cả ba tập, mapping 8 lớp, trùng xuyên tập, nhãn mâu thuẫn, RAM/thời gian và checksum nguồn đã có trong các báo cáo của lần chạy.
- Các dấu tick đã có của bạn được giữ lại. Pilot khoảng 100.000 dòng đã được đề xuất trong kế hoạch; chưa có tập pilot huấn luyện được xuất. Mẫu 100.000 dòng dùng khảo sát không được tính là pilot huấn luyện.
- Chưa đánh dấu hoàn thành toàn bộ task vì phần viết báo cáo còn mở; chưa có xác nhận nghiệm thu riêng của thành viên 2.
- Bước tiếp theo: [TV1-02](Thanh_vien_1_02_pipeline_tien_xu_ly.md).


## Ảnh đầu ra đã bàn giao

- [x] Đã lưu 7 ảnh PNG vào thư mục dự án, có thể mở để kiểm tra và dùng khi soạn báo cáo.

| File | Nội dung | Sử dụng trong bài toán 8 lớp |
| --- | --- | --- |
| [01_class_distribution.png](../plots/01_class_distribution.png) | Phân bố 34 nhãn gốc | Tài liệu nguồn/ánh xạ; biểu đồ chính dùng 8 nhóm |
| [02_category_distribution_8_classes.png](../plots/02_category_distribution_8_classes.png) | Phân bố đúng 8 nhóm | Biểu đồ phân bố lớp chính |
| [02b_class_imbalance_analysis.png](../plots/02b_class_imbalance_analysis.png) | Mất cân bằng theo 34 nhãn gốc | Cần tạo bản phân tích theo 8 nhóm trước khi dùng làm kết quả chính |
| [03_correlation_heatmap.png](../plots/03_correlation_heatmap.png) | Tương quan đặc trưng | Dùng cho khảo sát đặc trưng; chưa thay thế việc lựa chọn feature hợp lệ |
| [04_feature_distributions.png](../plots/04_feature_distributions.png) | Phân bố một số đặc trưng train | Dùng cho khảo sát; hình ghi 5.491.971 mẫu, tương ứng toàn bộ train đang dùng |
| [05_protocol_distribution.png](../plots/05_protocol_distribution.png) | Thống kê đặc trưng giao thức | Dùng cho mô tả đặc trưng; ghi đúng định nghĩa thống kê của notebook |
| [06_packet_flag_distribution.png](../plots/06_packet_flag_distribution.png) | Tỷ lệ giá trị khác 0 của các đặc trưng cờ | Dùng cho mô tả đặc trưng |

Trong hình 8 lớp, BruteForce có 1.541 mẫu nhưng tỷ lệ hiển thị `0.0%` do làm tròn một chữ số. Nên hiển thị ít nhất hai chữ số sau dấu phẩy: khoảng **0,03%**; Web-Based khoảng **0,05%**. Theo số đếm trên hình, tỷ số lớp lớn nhất/nhỏ nhất của **8 nhóm** là `3.998.500 / 1.541 ≈ 2.594,74 : 1`; tỷ số khoảng `6.058 : 1` trong ảnh `02b` thuộc 34 nhãn gốc, không dùng làm tỷ số mất cân bằng của bài toán 8 lớp. Các giá trị này tính từ số đếm đã lưu, chưa xác minh lại bằng CSV nguồn.

Các kiểm tra dữ liệu còn thiếu ở lần rà ảnh trước đã có kết quả trong run `20261007_164739_35f682b9`. Pipeline hiện xuất 44 feature sau khi bỏ Telnet/IRC; nháp báo cáo và pilot huấn luyện vẫn cần thực hiện. Các nhận xét về 7 ảnh phía trên mô tả bộ ảnh EDA ban đầu; biểu đồ processing mới nằm trong `../output/processed_data/20261007_164739_35f682b9/plots/`.
