# Thành viên 2 — 05: Hoàn thiện báo cáo mô hình và thực nghiệm

- **Lịch đề xuất:** viết nháp từ tháng 10; hoàn thiện 16–29/11; rà/nộp 30/11–06/12/2026.
- **Phụ thuộc:** số liệu cuối TV2-04; bảng thời gian XAI của TV3-04.
- **Người kiểm tra:** thành viên 1.

## Công việc

- [ ] Hoàn thiện 2.3, 3.3, cấu hình model của 4.1, 4.2 và phần suy luận của 4.4.
- [ ] Trình bày lựa chọn 3 thuật toán, preprocessing từng model, hyperparameter và ngân sách tìm kiếm; giải thích dùng validation/test.
- [ ] Kiểm tra mọi bảng mô hình/pilot/final/seed đều thuộc bài toán phân loại 8 lớp; thống nhất tên/thứ tự lớp và không trộn chỉ số của các lần chạy.
- [ ] Đối chiếu metrics từ dự đoán cuối, support và confusion matrix; giải thích macro-F1 và lớp hiếm.
- [ ] Viết phân tích ưu/nhược điểm và ca lỗi bằng số liệu thực; không khẳng định một model luôn tốt cho mọi mạng IoT.
- [ ] Hoàn thiện bảng thời gian, cỡ batch, phần cứng/RAM, phiên bản và phương pháp đo; kết hợp TV3 nhưng tách inference/XAI.
- [ ] Chuẩn bị model/config/metadata/log và hướng dẫn train/predict/evaluate; khóa phụ thuộc thực đã chạy ổn.
- [ ] Cùng nhóm viết kết luận, giới hạn và hướng phát triển; không tuyên bố XAI tự cải thiện accuracy.
- [ ] Rà phần dữ liệu của TV1 để đảm bảo số liệu/protocol khớp; cùng TV3 chạy demo và đối chiếu mẫu chuẩn.
- [ ] Chốt bộ kết quả/báo cáo trước 29/11; rà quyển và sao lưu trước 05/12 để nộp 06/12.

## Đầu ra và nghiệm thu

Bản thảo mô hình/thực nghiệm, bảng/hình cuối, artifact và hướng dẫn huấn luyện/suy luận, bảng đóng góp.

Đạt khi bảng tái tính được, mọi kết luận có số liệu, cấu hình và run ID truy vết được. Bản đầy đủ gửi nhóm rà ngày 22/11.

## Chuẩn bị trình bày

Giải thích vì sao dùng macro-F1, vì sao accuracy chưa đủ, cách chọn model mà không nhìn test, trade-off tài nguyên và giới hạn khả năng khái quát.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Ngày hoàn thành thực tế / bản báo cáo / đường dẫn / người kiểm tra: điền sau.
