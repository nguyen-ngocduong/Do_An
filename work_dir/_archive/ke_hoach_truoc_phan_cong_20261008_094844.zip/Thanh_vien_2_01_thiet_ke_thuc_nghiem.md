# Thành viên 2 — 01: Thiết kế thực nghiệm và tiêu chí đánh giá

- **Vai trò:** mô hình; ưu tiên thực hiện đầu tiên.
- **Lịch đề xuất:** 07–11/10/2026; 2–3 buổi.
- **Phụ thuộc:** có thể bắt đầu ngay; chốt protocol sau khi nhận kiểm kê TV1-01.
- **Người kiểm tra:** thành viên 3.

## Công việc

- [ ] Đọc đề cương, tài liệu [1]/[2]; tập trung phương pháp phân loại có giám sát 8 lớp và cách ánh xạ nhãn gốc sang 8 lớp.
- [x] Chốt bài toán duy nhất gồm Normal, BruteForce, DDoS, DoS, Mirai, Recon, Spoofing, Web-Based; nhãn gốc chỉ dùng để truy vết và kiểm tra mapping.
- [ ] Chọn Logistic Regression, Decision Tree, Random Forest cho đối sánh tối thiểu. Thống nhất feature/schema với TV1; thống nhất metadata suy luận với TV3.
- [ ] Viết protocol: cùng split, cùng dữ liệu train, seed cố định, preprocessing fit trên train, validation để chọn model, test chỉ dùng cuối.
- [x] Chọn macro-F1 validation làm chỉ số chính; thêm precision/recall/F1/support cho đủ 8 lớp, weighted-F1, accuracy và confusion matrix 8 × 8.
- [x] Chốt thứ tự/mã 8 lớp dùng chung: Normal=0, BruteForce=1, DDoS=2, DoS=3, Mirai=4, Recon=5, Spoofing=6, Web-Based=7; lưu `label_mapping.json`.
- [ ] Cụ thể hóa cách tính/báo cáo metric khi support bằng 0 hoặc chỉ số không xác định trong runner đánh giá.
- [ ] Đặt ngân sách pilot, số cấu hình tìm kiếm, thời gian/RAM; bắt đầu nhỏ rồi tăng theo pilot thay vì tìm kiếm toàn bộ dữ liệu.
- [ ] Thiết kế bảng kết quả và metadata: run ID, nguồn/split, seed, params, package, thời gian, feature/schema, model class order.
- [ ] Viết nháp mục 2.3, thiết kế thực nghiệm 4.1 và danh sách giả thuyết cần kiểm tra.

## Đầu ra và nghiệm thu

`docs/experiment_protocol.md`, cấu hình baseline dự kiến trong `configs/`, mẫu bảng metrics và `model_metadata.json`.

Đạt khi TV1/TV3 có thể hiểu chính xác dữ liệu vào/ra, cách chọn model và cách so sánh công bằng. Chưa điền số đo chưa chạy, chưa tuyên bố model nào tốt nhất.

## Cập nhật tiến độ

- Cập nhật: **08/10/2026**.
- Trạng thái: **đã chốt phạm vi 8 lớp, mapping và chỉ số; còn thiết kế thực nghiệm chi tiết**.
- Phạm vi 8 lớp do người dùng xác nhận; mapping có trong [artifact](../output/processed_data/20261007_164739_35f682b9/label_mapping.json). Macro-F1 và bảng metrics 8 lớp đã được quy định trong kế hoạch và hướng dẫn bước tiếp theo của notebook.
- Có đầu vào preprocessing để bắt đầu thiết kế baseline; chưa có runner huấn luyện, cấu hình tìm kiếm, ngân sách đã đo qua pilot hay kết quả mô hình.
- Còn chốt protocol/budget và tạo đầu ra thiết kế trước TV2-02.
- Bước tiếp theo: [TV2-02](Thanh_vien_2_02_huan_luyen_baseline.md).

