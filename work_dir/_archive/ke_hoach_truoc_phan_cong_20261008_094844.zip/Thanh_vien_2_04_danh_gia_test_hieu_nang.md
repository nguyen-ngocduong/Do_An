# Thành viên 2 — 04: Đánh giá test và hiệu năng xử lý

- **Lịch đề xuất:** 02–15/11/2026; đánh giá cuối mục tiêu 09–15/11; 4–5 buổi.
- **Phụ thuộc:** model/protocol đóng băng TV2-03; dữ liệu TV1-03 và xác nhận TV1-04.
- **Người kiểm tra:** thành viên 1.

## Công việc

- [ ] Ghi thời điểm đóng băng model/config; đánh giá các cấu hình đã chọn của 3 mô hình trên cùng test.
- [ ] Xuất precision/recall/F1/support cho đủ 8 lớp, macro-F1, weighted-F1, accuracy và confusion matrix 8 × 8 có nhãn trục đúng thứ tự.
- [ ] Phân tích các cặp lớp nhầm lẫn trong 8 lớp; báo riêng hiệu năng Normal, BruteForce, Web-Based và các lớp hiếm theo support thực tế.
- [ ] Lưu dự đoán test với sample ID, true/predicted label và xác suất theo class order; giao TV3 chọn ca XAI cuối.
- [ ] Phân tích nhầm lẫn phổ biến và lớp hiếm; không lấy điểm test để sửa/tinh chỉnh lại model.
- [ ] Benchmark cùng phần cứng/môi trường: warm-up, batch 1 và batch cố định phù hợp, ít nhất 30 lần nếu khả thi; báo cỡ mẫu và cách đo.
- [ ] Tách nạp model, preprocessing, prediction và end-to-end; ghi trung vị/p95, throughput mẫu/giây và RAM theo phương pháp đo.
- [ ] Tổng hợp thời gian fit từ log huấn luyện; không gộp SHAP vào thời gian suy luận model.
- [ ] Đối chiếu độ ổn định từ các seed thực chạy; nếu có lỗi thực nghiệm cần sửa, ghi bản bị hủy/lý do và giới hạn test đã được xem.
- [ ] Viết nháp 4.2 và phần thời gian suy luận/giới hạn 4.4; kiểm tra số liệu khớp artifact.

## Đầu ra và nghiệm thu

Bảng metrics test của 3 model, confusion matrix, `predictions.parquet` hoặc CSV, benchmark và ghi chú phân tích lỗi.

Đạt khi có thể tính lại bảng từ dự đoán đã lưu; protocol/test dùng chung; thời gian kèm máy/cỡ batch/số lần đo. Kết quả tốt hoặc thấp đều được báo trung thực.

## Cập nhật tiến độ

- Trạng thái: chưa bắt đầu.
- Test run ID / ngày đánh giá / đường dẫn / người kiểm tra: điền sau.
- Bước tiếp theo: [TV2-05](Thanh_vien_2_05_bao_cao_ban_giao.md).
